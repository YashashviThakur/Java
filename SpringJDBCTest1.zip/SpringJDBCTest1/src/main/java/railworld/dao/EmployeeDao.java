package railworld.dao;

import com.railworld.SpringJDBCTest1.Employee;

public interface EmployeeDao {
	public int insert(Employee employee);
	
	
}
