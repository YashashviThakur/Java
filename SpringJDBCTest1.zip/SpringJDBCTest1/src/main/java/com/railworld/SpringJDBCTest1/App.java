package com.railworld.SpringJDBCTest1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import railworld.dao.EmployeeDao;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "First Spring JDBC project" );
        ApplicationContext ctx = new ClassPathXmlApplicationContext("SpringConfig.xml");
        
        //Without Dao
//        JdbcTemplate template = ctx.getBean("jdbcTemplate",JdbcTemplate.class);
        
//        String query = "insert into employee values (?,?,?)";
//        int result = template.update(query,102,"Thakur","SoftwareDeveloper");
//        System.out.println("First Record Inserted " +result);
        
        //With Dao Package and files
        EmployeeDao emp = ctx.getBean("employeeDao",EmployeeDao.class);
        Employee emp1 = new Employee();
        emp1.setId(1001);
        emp1.setEname("Robert Downey Jr.");
        emp1.setDesgn("Ironman");
        int result = emp.insert(emp1);
        System.out.println("Record Inserted "+result);
    }
}
