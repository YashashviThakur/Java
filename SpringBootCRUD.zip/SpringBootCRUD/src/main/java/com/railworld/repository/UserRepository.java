package com.railworld.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.railworld.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
//here above student is the repository to manage, and long is the type of id that is defined in student repository

	
}
