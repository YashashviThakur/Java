package com.SpringCrud;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import com.SpringCrud.Model.Employee;
import com.SpringCrud.dao.EmployeeDao;

@Controller
public class HomeController {
	
	@Autowired
	private EmployeeDao employeeDao;
	
	@RequestMapping("/")
	public String home(Model m) {
		List<Employee> employees = employeeDao.getEmployees();
	     m.addAttribute("employees",employees);
		System.out.println(employees);
		return "index";
	}

	@RequestMapping("/addData")
	public String employeeData(Model m) {
		m.addAttribute("title", "Add Employee");
		return "add";
	}

	@RequestMapping(path = "/create", method = RequestMethod.POST)
	public RedirectView handleData(@ModelAttribute Employee employee, HttpServletRequest req) {
		System.out.println(employee);
		employeeDao.createProfile(employee);
		RedirectView view = new RedirectView();
		view.setUrl(req.getContextPath() + "/");
		return view;
	}
}
