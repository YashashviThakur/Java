package com.SpringCrud.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.SpringCrud.Model.Employee;

@Component
public class EmployeeDao {

    @Autowired
    private HibernateTemplate hibernateTemplate;
    
    @Transactional
    public void createProfile(Employee employee) {
        hibernateTemplate.save(employee);
    }

    public List<Employee> getEmployees() {
        return hibernateTemplate.loadAll(Employee.class);
    }
       @Transactional
    public void deleteEmployee(int eid) {
        Employee emp = hibernateTemplate.load(Employee.class, eid);
        hibernateTemplate.delete(emp);
    }

    public Employee getEmployee(int eid) {
        return hibernateTemplate.get(Employee.class, eid);
    }

    public void update(Employee emp) {
        hibernateTemplate.update(emp);
    }
}
