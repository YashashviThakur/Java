package com.railworld.SpringJdbcCRUD;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import railworld.dao.EmployeeDao;

public class App {

	public static void main(String[] args) {
		System.out.println("SpringJdbc CRUD Operation");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("SpringConfig.xml");

		EmployeeDao emp = ctx.getBean("EmployeeDao", EmployeeDao.class);
		Employee emp1 = new Employee();

		emp1.setEid(123123);
		emp1.setEname("Dwayne Johnson");
		emp1.setDesgn("Sr. Developer");
		int result = emp.insert(emp1);
		System.out.println("Recorded added " + result);
		
		
		//For updating the employee details
		Employee empToUpdate = new Employee();
		empToUpdate.setEid(123123);
		empToUpdate.setEname("The Rock");
		empToUpdate.setDesgn("Jr.Java Developer");
		int updateResult = emp.update(empToUpdate);
		System.out.println("Record updated: " + updateResult);

		//For deleting the employee details
		
//		int eidToDelete = 123123;
//		int deleteResult = emp.delete(eidToDelete);
//		System.out.println("Record deleted: " + deleteResult);

	}
}
