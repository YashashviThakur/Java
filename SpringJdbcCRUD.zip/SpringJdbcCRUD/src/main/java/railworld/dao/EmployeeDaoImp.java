package railworld.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.railworld.SpringJdbcCRUD.Employee;

public class EmployeeDaoImp implements EmployeeDao {

	private JdbcTemplate jdbctemplate;

	public int insert(Employee emp) {
		String query = "insert into employee value(?,?,?)";
		int r = this.jdbctemplate.update(query, emp.getEid(), emp.getEname(), emp.getDesgn());
		return r;
	}

	public int update(Employee employee) {
		String query = "update employee set ename=?, desgn=? where id=?";
		return jdbctemplate.update(query, employee.getEname(), employee.getDesgn(), employee.getEid());
	}

	public int delete(int eid) {
		String query = "delete from employee where id=?";
		return jdbctemplate.update(query, eid);
	}

	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}

}
