package railworld.SpringAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx= new ClassPathXmlApplicationContext("Spring.cfg.xml");
    	Student st=ctx.getBean("student", Student.class);
    	System.out.println(st);
    }
}
