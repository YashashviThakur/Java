package railworld.SpringAnnotation;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {
	@Value("Yashashvi Thakur")
	private String Studentname;
	@Value("Raipur")
	private String city;
	@Value("18")
	private int sid;
	@Value("Chhattisgarh")
	private String saddress;

	public String getStudentname() {
		return Studentname;
	}

	public void setStudentname(String studentname) {
		Studentname = studentname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSaddress() {
		return saddress;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

	@Override
	public String toString() {
		return "Student [Studentname=" + Studentname + ", city=" + city + ", sid=" + sid + ", saddress=" + saddress
				+ "]";
	}

}