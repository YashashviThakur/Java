package com.railworld.SpringORMCode;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.railworld.model.Student;
import com.railworld.service.StudentDao;


public class App 
{
    public static void main( String[] args )
    {
    	        ApplicationContext ctx = new ClassPathXmlApplicationContext("SpringConfig.xml");

    	        StudentDao stdDao = ctx.getBean("studentdao", StudentDao.class);
    	        Student std = new Student(111, "Robert Downey", "RWI101", "US");
    	        int r = stdDao.insert(std);
    	        System.out.println("Data Added Successfully..! " + r);
    	    }
    }