package com.railworld.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "StudentData")
public class Student {
	@Id
    @Column(name = "id")
    private int stdid;

    @Column(name = "Name")
    private String name;

    @Column(name = "RollNo")
    private String rollno;

    @Column(name = "Address")
    private String address;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int stdid, String name, String rollno, String address) {
		super();
		this.stdid = stdid;
		this.name = name;
		this.rollno = rollno;
		this.address = address;
	}

	public int getStdid() {
		return stdid;
	}

	public void setStdid(int stdid) {
		this.stdid = stdid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRollno() {
		return rollno;
	}

	public void setRollno(String rollno) {
		this.rollno = rollno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [stdid=" + stdid + ", name=" + name + ", rollno=" + rollno + ", address=" + address + "]";
	}
}
