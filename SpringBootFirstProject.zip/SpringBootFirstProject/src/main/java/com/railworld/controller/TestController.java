package com.railworld.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {


	@RequestMapping("/new")
		public String create() {
			System.out.println("Starting New Page");
			return "home";
		}

	@RequestMapping()
	public String about() {
		System.out.println("Opening About Section");
		return "about";
	}
}
