package com.railworld.FifthDayCode;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "ManyQuestion")
public class Questions {
	@Id
	private int id;
	private String QuestionName;
	@ManyToMany(targetEntity = Answer.class,cascade= {CascadeType.ALL})
	private List<Answer> answer;

	public Questions() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQuestionName() {
		return QuestionName;
	}

	public void setQuestionName(String questionName) {
		QuestionName = questionName;
	}

	public List<Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}

}
