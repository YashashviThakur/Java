package com.railworld.FifthDayCode;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		Transaction t = session.beginTransaction();

		Answer a1 = new Answer();
		a1.setId(1);
		a1.setAnswerName("Java is a programming language");
		a1.setPostedBy("Yashashvi Thakur");
		
		Answer a2 = new Answer();
		a1.setId(2);
		a2.setAnswerName("Python is a programming language");
		a2.setPostedBy("Robert Downey Jr.");
		
		Answer a3 = new Answer();
		a1.setId(3);
		a3.setAnswerName("C# is a programming language");
		a3.setPostedBy("Cilian Murphy");
		
		Answer a4 = new Answer();
		a1.setId(4);
		a4.setAnswerName("C++ is a programming language");
		a4.setPostedBy("Oscar");


		Questions q = new Questions();
		q.setId(121);
		q.setQuestionName("what is Java?");
		ArrayList<Answer> ans = new ArrayList<>();
		ans.add(a1);
		ans.add(a2);
		q.setAnswer(ans);


		Questions q1 = new Questions();
		q1.setId(122);
		q1.setQuestionName("what is C#?");
		ArrayList<Answer> ans2 = new ArrayList<>();
		ans2.add(a1);
		ans2.add(a2);
		q1.setAnswer(ans2);
		
		
		session.save(q);
	    session.save(q1);
		t.commit();
		session.close();
		factory.close();
		
		System.out.println("Complete mapping concept");

	}
}
