package com.railworld.ThirdCode;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		Transaction t = session.beginTransaction();

		Student s = new Student();
		s.setId(1);
		s.setSName("Yashashvi");
		s.setRollNo(101l);
		
		School s1 = new School();
		s1.setSchoolName("Railworld");
		s1.setSchoolAddress("Raipur");

		s.setSchool(s1);
		session.persist(s);
		t.commit();
		session.close();
		factory.close();

	}
}
