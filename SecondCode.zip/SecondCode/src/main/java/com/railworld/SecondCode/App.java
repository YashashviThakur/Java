package com.railworld.SecondCode;

import java.io.FileInputStream;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		EmployeeBean i = new EmployeeBean();
		i.setId(0);
		i.setPersonName("Yashashvi");
		try {
			FileInputStream a = new FileInputStream(
					"C:\\Users\\RCS\\eclipse-workspace\\SecondCode\\src\\main\\java\\sk.png");
			byte[] data = new byte[a.available()];
			a.read(data);
			i.setImage(data);
			a.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(i);
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(i);
		tx.commit();
		factory.close();
		session.close();

		System.out.println("Saved successfully.");

	}
}
