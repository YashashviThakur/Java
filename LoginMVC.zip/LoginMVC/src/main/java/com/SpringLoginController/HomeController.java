package com.SpringLoginController;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.SpringLoginModel.Employee;

@Controller
@RequestMapping("/home")
public class HomeController {
	@RequestMapping("/form")
	public String showpage() {
		return "form" ;
	}
	
	
	
	@RequestMapping(path ="/loginForm",method =RequestMethod.POST)
	public String createForm(@ModelAttribute Employee emp,Model model) {
		System.out.println(emp);
		model.addAttribute("emp", emp);
		return "home";	
	}

}
