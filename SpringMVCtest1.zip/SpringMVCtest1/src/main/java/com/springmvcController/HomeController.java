package com.springmvcController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping("/")
	public String demo() {
		System.out.println("This is home class");	
		return "index";
		}
	
	@RequestMapping("/show")
	public String view(Model model) {
		System.out.println("This is view Page");
		model.addAttribute("name","Yashashvi");
		List<String> ls = new ArrayList<String>();
		ls.add("Thakur");
		ls.add("Tony Stark");
		ls.add("Robert Downey Jr.");
		
		model.addAttribute("list",ls);
		
		return "home";
	}
	
	@RequestMapping("/new")
	public ModelAndView start() {
		System.out.println("Show the result");
		
		ModelAndView model1 = new ModelAndView();
		model1.addObject("id","RWI1234");
		model1.addObject("desgn","Developer");
		model1.setViewName("about");
		
		return model1;
	}
		
}
