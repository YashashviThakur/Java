package railworld.SpringAnnotationScope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx= new ClassPathXmlApplicationContext("Spring.cfg.xml");
    	Student st=ctx.getBean("b1", Student.class);
    	System.out.println(st);
		
		  Student st1=ctx.getBean("b1", Student.class);
		  System.out.println(st1.hashCode());
		 
    }
}
