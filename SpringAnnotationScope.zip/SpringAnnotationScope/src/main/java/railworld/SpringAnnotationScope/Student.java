package railworld.SpringAnnotationScope;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("b1")


 @Scope //same result every time called
 

/*
 * @Scope("prototype") // new result everytime called
 */ 
public class Student {
	@Value("Yashashvi Thakur")
	private List<String> Studentname;
	@Value("Raipur")
	private String city;
	@Value("#{T(java.lang.Math).sqrt(144)}")   //for printing id = 12
	private int sid;
	@Value("Chhattisgarh")
	private String saddress;
	
	public List<String> getStudentname() {
		return Studentname;
	}

	public void setStudentname(List<String> studentname) {
		Studentname = studentname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSaddress() {
		return saddress;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

	@Override
	public String toString() {
		return "Student [Studentname=" + Studentname + ", city=" + city + ", sid=" + sid + ", saddress=" + saddress
				+ "]";
	}

}