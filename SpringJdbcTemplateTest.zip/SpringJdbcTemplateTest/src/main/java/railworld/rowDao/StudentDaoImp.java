package railworld.rowDao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import railworld.rowBean.Student;

public class StudentDaoImp implements StudentDao {

	private JdbcTemplate jdbcTemplate;

	public int insert(Student student) {
		String query = "insert into student(id,name,city,state,pincode) values(?,?,?,?,?)";
		int r = this.jdbcTemplate.update(query, student.getId(), student.getName(), student.getCity(),
				student.getState(), student.getPincode());
		return r;
	}

	// Using queryforObject method to fetch complete table
	@Override
	public Student getStudent(int studentId) {
		String query = "select*from Student where id=?";
		RowMapper<Student> rowMapper = new RowMapperImp();
		Student record = this.jdbcTemplate.queryForObject(query, rowMapper, studentId);
		return record;
	}

	// Using query method to fetch complete table
	public List<Student> listStudents() {
		String SQL = "select * from Student";
		List<Student> students = this.jdbcTemplate.query(SQL, new RowMapperImp());
		return students;
	}

	public int update(Student student) {
		String query = "update student set name=?,city=?,state=?,pincode=? where id=?";
		return jdbcTemplate.update(query, student.getName(), student.getCity(), student.getState(),
				student.getPincode(), student.getId());
	}
	
	public int delete(Student student) {
		String query = "delete from student where id=?";
		return jdbcTemplate.update(query, student.getId());
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

}
