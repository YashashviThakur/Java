package railworld.rowDao;

import java.util.List;

import railworld.rowBean.Student;

public interface StudentDao {
	public int insert(Student student);

	public Student getStudent(int studentId);

	public int update(Student student);
	
	public int delete(Student student);

	public List<Student> listStudents();

}
