package com.railworld.SpringJdbcTemplateTest;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import railworld.rowBean.Student;
import railworld.rowDao.StudentDao;

public class App {
	public static void main(String[] args) {
		System.out.println("***** Program Started ******");
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
		StudentDao studentDao = context.getBean("StudentDao", StudentDao.class);
		Student st = new Student();

		// To add the elements into the table
//	    st.setId(1);
//	    st.setName("Robert Downney Jr.");
//	    st.setCity("Paris");
//	    st.setState("USA");
//	    st.setPincode(123421);
//		int result = studentDao.insert(st);
//		System.out.println("Student details added successfully " + result);

		// To update the elements in table
//		Student stdToUpdate = new Student();
//		stdToUpdate.setId(3);
//		stdToUpdate.setName("Yashashvi");
//		stdToUpdate.setCity("Durg");
//		stdToUpdate.setState("CG");
//		stdToUpdate.setPincode(567890);
//		int updateResult = studentDao.update(stdToUpdate);
//		System.out.println("Student Record updated: " + updateResult);

		// To delete the elements in table
//		Student idToDelete = new Student();
//		idToDelete.setId(2);
//		int deleteResult = studentDao.delete(idToDelete);
//		System.out.println("Record deleted: " + deleteResult);
//
//		List<Student> students = studentDao.listStudents();
//		for (Student record : students) {
//			System.out.println(record);
//		}

		// To get the table using RowMapping queryForObject method
//		Student student = studentDao.getStudent(3);
//		System.out.println(student);

		// To get the table using RowMapping queryForObject method
		System.out.println("------Listing Multiple Records--------");
		List<Student> students = studentDao.listStudents();

		for (Student record : students) {
			System.out.println(record);
		}

	}
}
