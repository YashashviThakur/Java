package com.railworld.FourthDayCode;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Answer_Q")
public class Answer {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private int id;
	private String answerName;
	private String postedBy;
	public Answer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAnswerName() {
		return answerName;
	}
	public void setAnswerName(String answerName) {
		this.answerName = answerName;
	}
	public String getPostedBy() {
		return postedBy;
	}
	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}
	@Override
	public String toString() {
		return "Answer [id=" + id + ", answerName=" + answerName + ", postedBy=" + postedBy + "]";
	}
	
	
	
}
