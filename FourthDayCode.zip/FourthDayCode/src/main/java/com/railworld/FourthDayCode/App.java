package com.railworld.FourthDayCode;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();
        
        Session session = factory.openSession();
        Transaction t = session.beginTransaction();
        
        Answer a1 = new Answer();
        a1.setAnswerName("Java is a programming language");
        a1.setPostedBy("Yashashvi Thakur");
        Answer a2 = new Answer();
        a2.setAnswerName("Python is a programming language");
        a2.setPostedBy("Robert Downey Jr.");
        Answer a3 = new Answer();
        a3.setAnswerName("C# is a programming language");
        a3.setPostedBy("Cilian Murphy");
        Answer a4 = new Answer();
        a4.setAnswerName("C++ is a programming language");
        a4.setPostedBy("Oscar");
        
        ArrayList<Answer> list1 = new ArrayList<Answer>();
        list1.add(a1);
        list1.add(a2);
        
        ArrayList<Answer> list2 = new ArrayList<Answer>();
        list2.add(a3);
        list2.add(a4);
        
        Questions q=new Questions();
        q.setQuestionName("what is Java?");
        q.setAnswer(list1);
        
        
        Questions q1=new Questions();
        q1.setQuestionName("what is C#?");
        q1.setAnswer(list2);
        

        session.persist(q);
        session.persist(q1);
        t.commit();
        session.close();
        factory.close();
        System.out.println("data saved");
        
        
    }
}
